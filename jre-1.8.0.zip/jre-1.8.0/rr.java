import java.util.*;

public class rr{
	public static void main(String[] args) {
		
		int num,quant,count=0,time=0,c;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter No. of proccesses:");
		num=sc.nextInt();
		System.out.println("Enter Quantum:");
		quant=sc.nextInt();
		int[] at=new int[num];
		int[] wt=new int[num];
		int[] ct=new int[num];
		int[] tat=new int[num];
		int[] arrive=new int[num];
		int[] finish=new int[num];
		int[] bt=new int[num];
		int[] rembt=new int[num];
		int[] queue=new int[100];
		int front=0,back=0;
		for(int i=0;i<num;i++)
		{
			System.out.println("Enter AT & BT:");
			at[i]=sc.nextInt();
			bt[i]=sc.nextInt();
			rembt[i]=bt[i];
			finish[i]=0;
			arrive[i]=0;
		}

		for(int i=0;i<num;i++)
		{
			if(at[i]<=time && ((finish[i]==0) && (arrive[i]==0)))
			{
				arrive[i]=1;
				queue[front]=i;
				front++;
			}
		}

		while(count<num)
		{
			c=queue[back];
			back++;

			if(quant>=rembt[c])
			{
				time=time+rembt[c];
				rembt[c]=0;
				finish[c]=1;
				count++;
				ct[c]=time;
			}
			else
			{
				time=time+quant;
				rembt[c]=rembt[c]-quant;
			}
			for(int i=0;i<num;i++)
		{
			if(at[i]<=time && (finish[i]==0 && arrive[i]==0))
			{
				arrive[i]=1;
				queue[front]=i;
				front++;
			}
		}
		if(finish[c]!=1)
		{
			queue[front]=c;
			front++;
		}
		}
		for(int i=0;i<num;i++)
		{
			tat[i]=ct[i]-at[i];
			wt[i]=tat[i]-bt[i];
			
		}
		for(int i=0;i<num;i++)
		{
			System.out.println("\t"+at[i]+"\t"+bt[i]+"\t"+tat[i]+"\t"+ct[i]+"\t"+wt[i]);
		}
	}
}