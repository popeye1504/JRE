import java.util.*;

public class lru{

	public static void main(String[] args) {
		

		Scanner sc=new Scanner(System.in);
		int frame,reflen,fault=0,hit=0,pointer=0,search;
		ArrayList<Integer> st=new ArrayList<Integer>();
		System.out.println("Enter no. of frames:");
		frame=sc.nextInt();
		System.out.println("Enter Length of Reference String:");
		reflen=sc.nextInt();
		int[] ref=new int[reflen];
		int[] buff=new int[frame];
		int[][] layout=new int[frame][reflen];
		System.out.println("Enter Refrence String:");
		for(int i=0;i<reflen;i++)
		{
			ref[i]=sc.nextInt();
		}

		for(int i=0;i<frame;i++)
		{
			buff[i]=-1;
		}

		for(int i=0;i<reflen;i++)
		{
			if(st.contains(ref[i]))
			{
				st.remove(st.indexOf(ref[i]));
			}
			st.add(ref[i]);
			search=-1;
			for(int j=0;j<frame;j++)
			{
				if(buff[j]==ref[i])
				{
					search=j;
					hit++;
					break;
				}
			}
			if(search==-1)
			{
				if(isFull)
				{	
					int min=reflen;
					for(int j=0;j<frame;j++)
					{
						if(st.contains(buff[j]))
						{
							int temp=st.indexOf(buff[j])
							if(temp<min)
							{
								min=temp;
								pointer=j;
							}
						}
					}
				}
				buff[pointer]=ref[i];
				pointer++;
				fault++;
				if(pointer==frame)
				{
					isFull=true;
					pointer=0;
				}	
			}

		}


	}
}